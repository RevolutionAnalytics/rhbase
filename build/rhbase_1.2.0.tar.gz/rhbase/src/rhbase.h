#ifndef	__rhbase_h
#define	__rhbase_h

#include <Rversion.h>
#include <R.h>
#include <Rdefines.h>
#include <Rinterface.h>
#include <Rembedded.h>
#include <R_ext/Boolean.h>
#include <R_ext/Parse.h>
#include <R_ext/Rdynload.h>
#define RNOMANGLE extern "C" 

#endif
